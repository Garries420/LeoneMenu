Leone Menu 1.0.0-test.16 - tester build

1. Close GTA San Andreas.
2. Copy the moonloader folder into the main GTA folder where gta_sa.exe is located.
3. Merge the folders and choose Replace if Windows asks.
4. Start SA-MP and type /leone in chat.

Built on Sputnik by Kev and Futurestunt. Leone Menu by Garry.
